package com.apesdev.S.core.hash;

public class Parameter {
    public static final String T_LOGIN = "login";
}
