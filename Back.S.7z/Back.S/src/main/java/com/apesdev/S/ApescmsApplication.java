package com.apesdev.S;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class ApescmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApescmsApplication.class, args);
	}
}
