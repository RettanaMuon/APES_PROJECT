package com.apesdev.S.core;

import org.bson.Document;

public interface Jsonable {
    Document toDocument();
}
