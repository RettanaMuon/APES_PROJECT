package com.apesdev.S.core.assets;

import org.bson.Document;

public abstract class Asset {
    public static Document json (Document doc){
        return doc;
    }
}
