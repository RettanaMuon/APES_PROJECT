package com.apesdev.S.core.parameter;

public class Collection {
    /* C  | collections variables */
     public static final String
            C_CATEGORIES = "categories",
            C_COMMENTS = "comments",
            C_COMS = C_COMMENTS,
            C_COUNTER = "counters",
            C_PUBLICATIONS = "publications",
            C_SESSIONS = "sessions",
            C_PUBS = C_PUBLICATIONS,
            C_USERS = "users"
              ;
}
