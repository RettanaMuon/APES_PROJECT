package com.apesdev.S.core.parameter;

public class Counters {
    public static final String
            COUNT_CATEGORIES = "categories_id",
            COUNT_COMMENTS = "comment_id",
            COUNT_PUBLICATIONS = "publications_id",
            COUNT_PUBS = COUNT_PUBLICATIONS,
            COUNT_PUBLICATIONS_COMMENT = "publication's counter of _id",
            COUNT_PUBS_COMMENT = COUNT_PUBLICATIONS_COMMENT
            ;
}
